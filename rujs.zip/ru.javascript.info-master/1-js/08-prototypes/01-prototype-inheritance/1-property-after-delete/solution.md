
1. `true`, берётся из `rabbit`.
2. `null`, берётся из `animal`.
3. `undefined`, такого свойства больше нет.
