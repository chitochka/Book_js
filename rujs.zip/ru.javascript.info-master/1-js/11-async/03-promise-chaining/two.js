function two() {
  alert(2);
}
