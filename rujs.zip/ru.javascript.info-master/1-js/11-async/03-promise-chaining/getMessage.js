function getMessage() {
  return "Привет, мир!";
}
