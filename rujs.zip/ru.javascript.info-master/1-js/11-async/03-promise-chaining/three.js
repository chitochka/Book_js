function three() {
  alert(3);
}
