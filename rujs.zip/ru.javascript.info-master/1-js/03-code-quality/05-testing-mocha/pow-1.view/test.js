describe("pow", function() {

  it("возводит число в степень n", function() {
    assert.equal(pow(2, 3), 8);
  });

});
