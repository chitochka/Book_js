describe("pow", function() {

  it("2 в степени 3 будет 8", function () {
    assert.equal(pow(2, 3), 8);
  });

  it("3 в степени 3 будет 27", function () {
    assert.equal(pow(3, 3), 27);
  });

});
