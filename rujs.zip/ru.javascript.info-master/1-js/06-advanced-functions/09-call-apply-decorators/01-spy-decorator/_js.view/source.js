function spy(func) {
  // ваш код
}


