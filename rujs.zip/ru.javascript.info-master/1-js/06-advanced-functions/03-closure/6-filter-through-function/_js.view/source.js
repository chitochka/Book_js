
let arr = [1, 2, 3, 4, 5, 6, 7];

function inBetween(a, b) {
  // ...your code...
}

function inArray(arr) {
  // ...your code...
}
