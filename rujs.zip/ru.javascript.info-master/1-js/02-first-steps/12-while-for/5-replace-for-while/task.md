importance: 5

---

# Замените for на while

Перепишите код, заменив цикл `for` на `while`, без изменения поведения цикла.

```js run
for (let i = 0; i < 3; i++) {
  alert( `number ${i}!` );
}
```
