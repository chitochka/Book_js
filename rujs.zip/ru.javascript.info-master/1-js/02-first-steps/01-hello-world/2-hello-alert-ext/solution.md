HTML-код:

[html src="index.html"]

Для файла `alert.js` в той же папке:

[js src="alert.js"]

