importance: 5

---

# if (строка с нулём)

Выведется ли `alert`?

```js
if ("0") {
  alert( 'Привет' );
}
```
