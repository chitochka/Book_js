importance: 5

---

# Операторы сравнения

Каким будет результат этих выражений?

```js no-beautify
5 > 4
"ананас" > "яблоко"
"2" > "12"
undefined == null
undefined === null
null == "\n0\n"
null === +"\n0\n"
```

