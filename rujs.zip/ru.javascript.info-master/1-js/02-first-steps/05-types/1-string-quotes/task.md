importance: 5

---

# Шаблонные строки

Что выведет этот скрипт?

```js
let name = "Ilya";

alert( `hello ${1}` ); // ?

alert( `hello ${"name"}` ); // ?

alert( `hello ${name}` ); // ?
```
