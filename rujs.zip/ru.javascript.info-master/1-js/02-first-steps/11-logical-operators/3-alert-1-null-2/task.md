importance: 5

---

# Что выведет alert (И)?

Что выведет код ниже?

```js
alert( 1 && null && 2 );
```

