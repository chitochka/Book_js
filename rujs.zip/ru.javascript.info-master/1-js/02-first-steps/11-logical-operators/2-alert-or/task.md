importance: 3

---

# Что выведет alert (ИЛИ)?

Что выведет код ниже?

```js
alert( alert(1) || 2 || alert(3) );
```

