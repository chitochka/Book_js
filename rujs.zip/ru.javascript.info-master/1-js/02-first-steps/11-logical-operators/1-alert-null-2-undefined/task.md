importance: 5

---

# Что выведет alert (ИЛИ)?

Что выведет код ниже?

```js
alert( null || 2 || undefined );
```

