importance: 3

---

# Что выведет alert (И)??

Что выведет код ниже?

```js
alert( alert(1) && alert(2) );
```

