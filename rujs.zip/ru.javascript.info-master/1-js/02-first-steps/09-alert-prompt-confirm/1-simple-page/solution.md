JavaScript-код:

```js demo run
let name = prompt("Ваше имя?", "");
alert(name);
```

Вся страница:

```html
<!DOCTYPE html>
<html>
<body>

  <script>
    'use strict';

    let name = prompt("Ваше имя?", "");
    alert(name);
  </script>

</body>
</html>
```
