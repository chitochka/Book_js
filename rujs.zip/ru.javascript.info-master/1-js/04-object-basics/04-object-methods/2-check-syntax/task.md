importance: 2

---

# Проверка синтаксиса

Каким будет результат выполнения этого кода?


```js no-beautify
let user = {
  name: "Джон",
  go: function() { alert(this.name) }
}

(user.go)()
```

P.S. Здесь есть подвох :)
